#ifndef __H_PRIME_GENERATOR__
#define __H_PRIME_GENERATOR__


int prime_next(int lower_bound);
int prime_check(int num);

#endif